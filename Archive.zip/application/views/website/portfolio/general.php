<div class="container">
    <h2 align="center"><?php if(isset($name)){ echo $name; }?></h2>

    <hr>

    <div class="row">
        <?php if(isset($content)){ echo $content; }?>
    </div><!-- /.row -->

</div><!-- /.container -->
