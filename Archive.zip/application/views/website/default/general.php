<div class="body-area">
<div class="body-con-area">
<div class="service-page-con">
<h1><?php if(isset($name)){ echo $name; }?></h1>
        <?php if(isset($content)){ echo $content; }?>
</div>
</div>
</div>
</div>
