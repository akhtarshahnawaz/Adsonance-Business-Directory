Dear <?php echo ucfirst(strtolower($name)); ?>
Thank you for registering  with Adsonance Local Businesses Directory


You have Successfully reset your Account.




For any query related to account contact us at:

E-Mail: support@adsonance.com
Phone: +91-9810344604
Website: http://adsonancebusiness.com
