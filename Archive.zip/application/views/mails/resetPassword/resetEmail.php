Hello <?php echo $userInfo['name']; ?>

You requested to reset your password on Adsonance Local Businesses Directory

Click on link below to reset your account password

    <?php echo site_url('index/resetPassword').'/'.$generatedVCode; ?>







If this reset request isn't initiated by you then ignore this message

For any query related to account contact us at:
E-Mail: support@adsonance.com
Phone: +91-9810344604
Website: http://adsonancebusiness.com
