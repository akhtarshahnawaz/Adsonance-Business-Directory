
<div class="row-fluid"  style="padding: 0px; margin: 0px; bottom: 0px; background-color: #EEEEEE; border-top: solid thin #ccc;">
        <div class="span12">
        	<p align="center" style="color: #000"><?php echo $this->config->item('footerCopyMessage');?></p>
        </div>
</div>

</body>
</html>
