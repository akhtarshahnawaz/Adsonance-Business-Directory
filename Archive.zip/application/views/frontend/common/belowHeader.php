    <div class="row-fluid">
        <div class="span1"></div>
        <div class="span3"> </div>
        <div class="span3"><a href="<?php echo site_url();?>"> <img src="<?php linkAsset('images/logoBlack.png'); ?>"  width="500px" height="100px"/></a></div>
        <div class="span3"></div>
        <div class="span1"></div>
    </div>
    </br></br>

