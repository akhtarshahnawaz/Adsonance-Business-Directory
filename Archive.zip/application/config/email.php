<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*EMAIL CONFIGURATIONS*/

$config['protocol'] = 'smtp';
$config['charset'] = 'iso-8859-1';
$config['wordwrap'] = TRUE;
$config['smtp_host']='mail.adsonance.com';
$config['smtp_user']='support@adsonance.com';
$config['smtp_pass']='Gc@949000';
$config['smtp_port']=25;
$config['priority']=1;
$config['crlf']="\r\n";