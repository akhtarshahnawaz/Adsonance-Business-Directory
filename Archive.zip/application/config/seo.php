<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


//HomePage

$config['homepageTitle'] = 'Adsonance Local Businesses Directory';
$config['categoryTitle'] = ' | Adsonance Local Businesses';
$config['SearchTitle'] = ' | Adsonance Local Businesses';
$config['singleListingTitle'] = ' | Adsonance Local Businesses |';
$config['PageTitle'] = ' | Adsonance Local Businesses';



$config['homepageDescription']="Find Local Business like theatres, restaurant, construction etc";
