<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


//HomePage

$config['LogoUploadDirectory'] = 'website/logo/';
$config['FaviconUploadDirectory'] = 'website/favicon/';
$config['SlideshowImageUploadDirectory'] = 'website/slideshow/';
$config['websiteInContentFilesDirectory'] = 'website/inContentFiles/';







$config['websiteAddress']='adsonancebusiness.com,business.adsonance.com,adsonance.com/adsonanceLocalBusiness,adsonance.com';



//Image Sizes


$config['LogoWidth']=300;
$config['LogoHeight']=120;
$config['LogoSize']=300;

$config['FaviconWidth']=64;
$config['FaviconHeight']=64;
$config['FaviconSize']=100;

